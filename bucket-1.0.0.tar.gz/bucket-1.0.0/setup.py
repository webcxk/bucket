from setuptools import setup, find_packages

setup(
    name='bucket',
    version='1.0.0',
    author='mamga',
    author_email='webcxk@outlook.com',
    description='更简单的操作栈和命令!',
    packages=find_packages(),
)
